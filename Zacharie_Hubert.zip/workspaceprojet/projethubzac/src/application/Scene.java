package application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;

public class Scene {

	public int id;
	public String nom;
	public String style;
	public float surface;
	public String nom_festival;
	private int capacity;
	
	//Constructor
	public Scene(int id) {
		this.id = id;
	}
	
	public Scene(String nom, float surface, String style,  int capacity) {
		this.nom = nom;
		this.surface = surface;
		this.style = style;
		this.capacity = capacity;
	}
	
	//Methods
	/**
	 * ajoute une scene � la base de donn�es
	 * @param nom
	 * @param surface
	 * @param style
	 * @param capacity
	 * @throws SQLException
	 */
	public void ajouter_scene_bdd(String nom, float surface, String style, int capacity) throws SQLException {
		Connection connection = Connexion.getInstance();
		String sql = "INSERT INTO scene (nom,surface,style,capacity) VALUES (?,?,?,?)";
		PreparedStatement pStatement = connection.prepareStatement(sql);
		pStatement.setString(1, nom);
		pStatement.setFloat(2, surface);
		pStatement.setString(3, style);
		pStatement.setInt(4, capacity);
		pStatement.execute();
	}	
	
	/**
	 * retourne l'heure � laquelle une sc�ne est disponible
	 * @param id_scene
	 * @param jour
	 * @throws SQLException
	 */	
	public static Time est_disponible(int id_scene, String jour) throws SQLException{
		Connection connection = Connexion.getInstance();
		PreparedStatement pStatement = connection.prepareStatement("SELECT MAX(heurefin) FROM concert WHERE sceneid = ?"
				+ " AND jour LIKE ?");
		pStatement.setInt(1, id_scene);
		pStatement.setString(2, jour);
		ResultSet result = pStatement.executeQuery();
		result.next();
		Time heuredispo = result.getTime("max");
		System.out.println("La sc�ne "+ id_scene + " sera disponible � "+ heuredispo +".");
		return heuredispo;
		}
	
}
