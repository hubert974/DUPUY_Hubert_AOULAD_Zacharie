package application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Materiel {
	
	private int id;
	private String type;
	private int id_scene;
	
	//Constructor
	public Materiel() {
	}
	
	//Methods
	
	/**
	 * Verifie si une certaine quantit� d'un type de mat�riel est disponible � une heure donn�e (mat�riel dont l'artiste a besoin) (seulement un type)
	 * @param type
	 * @param qte
	 * @param heure
	 * @throws SQLException
	 * @return
	 */
	public static boolean verifier_disponibilite(String type, int qte, Time heure) throws SQLException {
		Connection connection = Connexion.getInstance();
		PreparedStatement pStatement = connection.prepareStatement( "SELECT COUNT (DISTINCT (materiel.id)) FROM materiel" + 
				" JOIN concert ON concert.sceneid = materiel.id_scene" +
				" WHERE (type LIKE ? AND id_scene = 0)" + //si le mat�riel est dans la r�serve
				" OR (type LIKE ? AND (? >= heurefin))" + //� la fin d'un concert sur la sc�ne
				" GROUP BY id_scene");
		pStatement.setString(1, type);
		pStatement.setString(2, type);
		pStatement.setTime(3, heure);
		ResultSet result = pStatement.executeQuery();
		result.next();
		int somme = 0;
		while (result.next()) {
			somme = somme + result.getInt(1);
		};
		if (qte <= somme) {
			System.out.println("Le(s) " + qte + type + "(s) "  + "est/sont disponible(s).");
			return true;
		}
		else {
			System.out.println("La quantit� demand�e de " + type + " n'est pas disponible.");
			return false;	
		}
	}
	
	/**
	 * Retourne une map des identifiants disponibles par sc�ne : on utilise cette fonction seulement si tous les types sont dispo
	 * @param type
	 * @param qte
	 * @param heure
	 * @return 
	 * @throws SQLException 
	 */
	public static Map<Integer, List<Integer>> mapid(String type, int qte, Time heure) throws SQLException {
		Connection connection = Connexion.getInstance();
		PreparedStatement pStatementm = connection.prepareStatement( "SELECT materiel.id_scene,materiel.id FROM materiel" + 
				" JOIN concert ON concert.sceneid = materiel.id_scene" +
				" WHERE (type LIKE ? AND id_scene = 0)" + //si le mat�riel est dans la r�serve
				" OR (type LIKE ? AND (? >= heurefin))" + //� la fin d'un concert sur la sc�ne
				" GROUP BY materiel.id_scene,materiel.id" +
				" ORDER BY materiel.id_scene"
				+ " LIMIT ?");
		pStatementm.setString(1, type);
		pStatementm.setString(2, type);
		pStatementm.setTime(3, heure);
		pStatementm.setInt(4, qte);
		ResultSet resultm = pStatementm.executeQuery();
		
		Map<Integer, List<Integer>> m_Map = new HashMap<Integer, List<Integer>>(); //On initialise la map
		
		if (resultm.next()) {
		
			int num = -1;
			num = resultm.getInt(1);
			ArrayList<Integer> liste = new ArrayList<Integer>();
			liste.add(resultm.getInt(2));
			while (resultm.next()) {
				if (resultm.getInt(1) == num) {
					liste.add(resultm.getInt(2));
				}
				else {
					m_Map.put(num, liste);
					num = resultm.getInt(1);
					liste = new ArrayList<Integer>();
				}
			}
			
			m_Map.put(num, liste);
		}
		
		return m_Map;
	}
		
	//pour les id dans la liste des identifiants des matos dispo
	
	
	/**
	 * Permet de d�placer une entit� d'une sc�ne � une autre
	 * @param id
	 * @param id_scenedep
	 * @param id_scenefin
	 * @throws SQLException
	 */
	public static void deplacer_materiel(int id, int id_scenedep, int id_scenefin) throws SQLException {
		Connection connection = Connexion.getInstance();
		String sql = "UPDATE mat�riel SET id_scenefin = ? WHERE id = ? AND id_scenedep = ?";
		PreparedStatement pStatement2 = connection.prepareStatement(sql);
		pStatement2.setInt(1, id_scenefin);
		pStatement2.setInt(2, id_scenefin);
		pStatement2.setInt(3, id_scenefin);
		pStatement2.executeUpdate();
	}
		
	/**
	 * Permet d'enlever tout le mat�riel sur une sc�ne et le mettre dans la r�serve (utile en fin de journ�e)
	 * @param id_scene
	 * @throws SQLException
	 */
	public static void vider_scene(int id_scene) throws SQLException {
		Connection connection = Connexion.getInstance();
		String sql = "UPDATE materiel SET id_scene = 0 WHERE id_scene = ?"; //id reserve = 0
		PreparedStatement pStatement = connection.prepareStatement(sql);
		pStatement.setInt(1, id_scene);
		pStatement.executeUpdate();
	}
	
	/**
	 * Permet d'ajouter du mat�riel dans la base de donn�es (apr�s une commande de mat�riel)
	 * @throws SQLException
	 */
	public static void ajouter_materiel_bdd() throws SQLException {
		Connection connection = Connexion.getInstance();
		String rep = "oui"; //initialisation
		Scanner scan = new Scanner (System.in);
		while (rep.equals("oui")) {
			System.out.println("Quel type de mat�riel voulez-vous ajouter ?");
			String mat  = scan.nextLine();
			System.out.println("En quelle quantit� ?");
			int qte  = scan.nextInt();
			for(int i=0; i < qte; i++) {
				String sql = "INSERT INTO materiel (type,id_scene) VALUES (?,?)";
				PreparedStatement pStatement = connection.prepareStatement(sql);
				pStatement.setString(1, mat);
				pStatement.setInt(2, 0);
				pStatement.execute();
				}
			System.out.println("Voulez-vous ajouter autre chose ? (oui/non)");
			  //On r�cup�re la r�ponse de l'utilisateur
			rep = scan.next();
			scan.nextLine();
			}
		scan.close();
	}
}
