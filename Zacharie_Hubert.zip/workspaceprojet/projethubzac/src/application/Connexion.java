package application;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connexion {
	
	private static final String DB_URL = "jdbc:postgresql://localhost:5432/application";
	private static final String DB_USER = "postgres";
	private static final String DB_PSWD = "HubZac";
	
	private static Connection connection; // l�objet Connection

	private Connexion() {
		try {
			Connexion.connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PSWD);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static Connection getInstance() {
		if (Connexion.connection == null) {
			new Connexion();
		}
		return Connexion.connection;
	}
}
