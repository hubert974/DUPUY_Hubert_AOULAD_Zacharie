package application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.*;

import javax.mail.*;
import javax.mail.internet.*;
import javax.mail.internet.MimeMessage;
public class Billet {
	
	private int id;
	private String dateachat;
	private String pass; //pass1jour, pass2jours, pass3jours;
	private List<String> jours;
	
	// ********* Constructors *************
	
	public Billet(int id, String date_achat, String pass) {
		this.id = id;
		this.dateachat = date_achat;
		this.pass = pass;
		this.jours = new ArrayList<String>();
		
	}
	
	// ********* Assessors *************
	
	//Retourne l'identifiant du billet
	public int getId() {
		return this.id;
	}
	
	// Retourne la date d'achat du billet
	public String getdateachat(){
		return this.dateachat;
	}
	
	// Retourne le pass choisi
	public String getPass() {
		return this.pass;
	}
	
	//Retourne la liste des jours choisis
	public List<String> getJours() {
		return this.jours;
	}
	
	// ********* Methods *************
	
	public void ajouterbilletbdd(String jours) throws SQLException {
		Connection connection = Connexion.getInstance();
		String sql = "INSERT INTO billet (dateachat,pass,jours) VALUES (?,?,?)";
		PreparedStatement pStatement = connection.prepareStatement(sql);
		pStatement.setString(1, this.getdateachat());
		pStatement.setString(2, this.getPass());
		pStatement.setString(3, jours);
		pStatement.execute();
	}
	
	public int places_disponibles(Concert concert) {
		return concert.getPlacesdispo();
	}
	
	public void enlever_une_place(Concert concert) {
		int nb = concert.getPlacesdispo();
		concert.setPlacesdispo(nb - 1);
	}
	
	public void annuler_billet(int id) throws SQLException {
		Connection connection = Connexion.getInstance();
		String sql = "DELETE FROM billet WHERE id = ?";
		PreparedStatement pStatement = connection.prepareStatement(sql);
		pStatement.setInt(1, id);
		pStatement.execute();
			if (this.jours.size()==1) {
				String sql1 = "UPDATE FROM concert SET placesdispo = placesdispo + 1 WHERE jour = ?";
				PreparedStatement pStatement1 = connection.prepareStatement(sql1);
				pStatement1.setString(1, jours.get(0));
				pStatement1.execute();
			}
			if (this.jours.size()==2) {
				String sql2 = "UPDATE FROM concert SET placesdispo = placesdispo + 1 WHERE jour = ?";
				PreparedStatement pStatement2 = connection.prepareStatement(sql2);
				pStatement2.setString(1, jours.get(0) + " et " + jours.get(1));
				pStatement2.execute();
			}
			if (this.jours.size()==3) {
				String sql3 = "UPDATE FROM concert SET placesdispo = placesdispo + 1 WHERE jour = ?";
				PreparedStatement pStatement3 = connection.prepareStatement(sql3);
				pStatement3.setString(1, jours.get(0) + " et " + jours.get(1) + " et " + jours.get(2));
				pStatement3.execute();
			}
	}
	
	public void addJour(String jour) {
		jours.add(jour);
	}
	
	public String afficher_informations() {
		String str = ("Bonjour, " + 
				"votre identifiant billet est " + this.getId() +
				 ", vous avez achet� le " + this.getdateachat() + " un billet " + this.getPass() +
				 " pour ");
		if (jours.size() == 1) {
			str = str + "le " + jours.get(0);
		}
		if (jours.size() == 2) {
			str = str + "les " + jours.get(0) + "et " + jours.get(1);
		}
		if (jours.size() == 3) {
			str = str + "les " + jours.get(0) + "et " + jours.get(1) + "et " + jours.get(2);
		}
	return str;
	}
	
	
	public static void main(String[] args) {
		
		//Cr�ation d'un billet
		Billet b = new Billet(1,"06/05/2018","pass 1 jour");
		//jour associ� au pass
		b.addJour("10/07/2018");
		
		//try {
		//	b.ajouterbilletbdd("10/07/2018");
		//} catch (SQLException e) {
		//	// TODO Auto-generated catch block
		//	e.printStackTrace();
		//}
		
		//b.afficher_informations();
		try{
			Scanner scan=new Scanner(System.in);
			System.out.println("Entrez votre adresse mail");
			String mailfestivalier= scan.nextLine();
            String host ="smtp.gmail.com" ;  //utilisation serveur smtp de google car gratuit, necessaire pour l'envoie d'un mail java
            String user = "festivalhubzac@gmail.com";// mon adresse mail
            String pass = "projethubzac";					//le mdp de mon compte
            String to = mailfestivalier; //destinataire
            String from = "Festizachub";
            String subject = "Informations festival";//Sujet du mail
            String messageText = b.afficher_informations();//Texte du mail
            
            boolean sessionDebug = false;

            Properties props = System.getProperties();

            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", host);
            props.put("mail.smtp.port", "587");//adresse de la smtp
            props.put("mail.smtp.auth", "true");//auth r�ussie
            props.put("mail.smtp.starttls.required", "true");
            props.put("mail.smtp.ssl.trust", "smtp.gmail.com");//s�curit� reconnue suffisante pour l'envoie
            java.security.Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());//s�curit� compl�mentaire fournie par java
            Session mailSession = Session.getDefaultInstance(props, null);
            mailSession.setDebug(sessionDebug);
            Message msg = new MimeMessage(mailSession);//envoie du mail grace � la boite mail
            msg.setFrom(new InternetAddress(from));//ajout de l'adresse internet du compte �metteur aux donn�es annexes du mail
            InternetAddress[] address = {new InternetAddress(to)};//adresse du destinataire ajout�e sur la boite mail
            msg.setRecipients(Message.RecipientType.TO, address);
            msg.setSubject(subject); msg.setSentDate(new Date());
            msg.setText(messageText);

           Transport transport=mailSession.getTransport("smtp");
           transport.connect(host, user, pass);
           transport.sendMessage(msg, msg.getAllRecipients());
           transport.close();
           System.out.println("Les messages de confirmation ont bien �t� envoy�s.");
        }
        catch(Exception ex)
        
        {
            System.out.println(ex);
        }

    }

	
}
