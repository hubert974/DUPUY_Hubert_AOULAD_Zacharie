package application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Time;
import java.util.List;

public class Concert {
	
	private int id;
	private String nom;
	private String jour;
	private Time heuredebut;
	private Time heurefin;
	private int sceneid;
	private int placesdispo;
	private Artiste artiste;
	
	//Constructors
	public Concert(int id) {
		this.id = id;
	}
	
	public Concert(String nom) {
		this.nom = nom;
	}
	
	public Concert(String nom, String jour, Time heureDebut, Time heureFin, int sceneId) {
		this.nom = nom;
		this.jour = jour;
		this.heuredebut = heureDebut;
		this.heurefin = heureFin;
		this.sceneid = sceneId;
	}
	
	//Assessors
	public int getId() {
		return this.id;
	}
	
	public String getNom() {
		return this.nom;
	}
	
	public String getJour() {
		return this.jour;
	}
	
	public Time getHeureDebut() {
		return this.heuredebut;
	}
	
	public Time getHeureFin() {
		return this.heurefin;
	}
	
	public int getSceneId() {
		return this.sceneid;
	}
	
	public Artiste getArtiste() {
		return this.artiste;
	}
	
	public int getPlacesdispo() {
		return this.placesdispo;
	}
	
	//Mutator
	public void setPlacesdispo(int placesdispo) {
		this.placesdispo=placesdispo;
	}
	
	//Methods
	
	/**
	 * ajoute un concert dans la base de donn�es
	 */
	public void ajouter_concert_bdd(int id_artiste) throws SQLException {
		Connection connection = Connexion.getInstance();
		String sql = "INSERT INTO concert (nom,jour,heuredebut,heurefin,sceneid,id_artiste) VALUES (?,?,?,?,?,?)";
		PreparedStatement pStatement = connection.prepareStatement(sql);
		pStatement.setString(1, this.getNom());
		pStatement.setString(2, this.getJour());
		pStatement.setTime(3, this.getHeureDebut());
		pStatement.setTime(4, this.getHeureFin());
		pStatement.setInt(5, this.getSceneId());
		pStatement.setInt(6, id_artiste);
		pStatement.execute();
	}
	
	
}
