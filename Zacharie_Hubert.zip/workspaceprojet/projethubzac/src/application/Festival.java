package application;

///L'utilisateur doit choisir les jours de son festival du type 10/07/2018

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Festival {
	
	private String nom; 
	private int nbplaces;
	private List<Concert> concerts;
	public List<Scene> scenes;
	
	//Constructors
	public Festival(String nom, int nbplaces) {
		this.nom = nom;
		this.nbplaces = nbplaces;
	}
	
	public Festival(String nom, int nbplaces, List<Concert> concerts) {
		this.nom = nom;
		this.nbplaces = nbplaces;
		this.concerts = new ArrayList<Concert>();
		this.scenes = new ArrayList<Scene>();
	}
	
	//Assessors
	public String getNom() {
		return this.nom;
	}
	
	public int getNombrePlaces() {
		return this.nbplaces;
	}
	
	public List<Concert> getConcerts(){
		return this.concerts;
	}
	
	public List<Scene> getScenes(){
		return this.scenes;
	}
	
	//Methods
	/**
	 *ajoute du mat�riel dans la r�serve
	 * @throws SQLException 
	 */
	public void ajouterfestivalbdd() throws SQLException {
		Connection connection = Connexion.getInstance();
		String sql = "INSERT INTO festival (nom, nb_places) VALUES (?, ?)";
		PreparedStatement pStatement = connection.prepareStatement(sql);
		pStatement.setString(1, this.getNom());
		pStatement.setInt(2, this.getNombrePlaces());
		pStatement.execute();
	}
	
	/**
	 *ajoute une sc�ne � la liste des sc�nes
	 */
	public void addScene(Scene scene) {
		this.scenes.add(scene);
	}
	
	/**
	 *propose � l'artiste de participer au festival 
	 * @param nom
	 * @param jour
	 * @param prix
	 */
	public boolean inviter_artiste(String nom, String jour, float prix) {
		Scanner scan = new Scanner(System.in);
		System.out.println("L'artiste " + nom +" souhaite-t-il participer au festival '" + this.getNom()
		+ "' le " + jour + " pour un prix de " + prix + " euros ? " +
		"(vous devez r�pondre par 'true' ou par 'false')");
		try {
			boolean reponse = scan.nextBoolean();
			
			scan.nextLine();
			if (reponse == true) {
			System.out.println("L'artiste accepte la demande.");
			}
			else if (reponse == false) {
			System.out.println("L'artiste refuse la demande.");
			}
			//scan.close();
			return reponse;
		} catch (InputMismatchException error) {
			System.out.println("Veuillez recommencer.");
			return this.inviter_artiste(nom, jour, prix);
		}
	}
	
	/**
	 *ajoute un concert � la liste des concerts
	 */
	public void addConcert(Concert concert) {
		this.concerts.add(concert);
	}
	
	
	
	/**
	 *annule la participation de l'artiste au festival 
	 * @param nom
	 * @param jour
	 * @param prix
	 */
	
	public void annuler_participation(Artiste artistesup) throws SQLException {
		
		//On supprime dans la liste des concerts
		Iterator<Concert> i = concerts.iterator();
		while ( i.hasNext() ) {
		    Concert concert = i.next();
		    Artiste artiste = concert.getArtiste();
		    if (artiste == artistesup) {
		        // On supprime l'�l�ment de la liste
		        i.remove();
		    }
		}
		
		//On supprime dans la base de donn�es
		Connection connection = Connexion.getInstance();
		String sql1 = "DELETE FROM artiste WHERE id = ?";
		String sql2 = "DELETE FROM concert WHERE id_artiste = ?";
		PreparedStatement pStatement1 = connection.prepareStatement(sql1);
		PreparedStatement pStatement2 = connection.prepareStatement(sql2);
		pStatement1.setInt(1, artistesup.getId());
		pStatement2.setInt(2, artistesup.getId());
		pStatement1.execute();
		pStatement2.execute();
	}
	
	/**
	 * ajoute un concert du type 'phase de pr�paration'
	 * @param jour
	 * @param heuredebut
	 * @param heurefin
	 * @param sceneid
	 * @throws SQLException
	 */
	public static void ajouter_phase_preparation_bdd(String jour, Time heuredebut, Time heurefin, int sceneid) throws SQLException {
		//a modifier::::::Le laps de temps sera d'autant plus important 
		//que la configuration de la sc�ne sera modifi�e.
		Connection connection = Connexion.getInstance();
		String sql = "INSERT INTO concert (nom,jour,heuredebut,heurefin,sceneid) VALUES (?,?,?,?,?)";
		PreparedStatement pStatement = connection.prepareStatement(sql);
		pStatement.setString(1, "phase de pr�paration");
		pStatement.setString(2, jour);
		pStatement.setTime(3, heuredebut);
		pStatement.setTime(4, heurefin);
		pStatement.setInt(5, sceneid);
		pStatement.execute();
	}
	
	public static void main(String[] args) throws SQLException {
		
		Connection connection = Connexion.getInstance();
		Scanner scan = new Scanner(System.in);
		System.out.println("Bonjour, bienvenue sur notre application d�di�e � l'organisation de festivals.");
		System.out.println("\n");
		System.out.println(
				"Si vous voulez ajouter un nouveau festival, tapez 1.\n"+
				"Si vous souhaitez r�cup�rer un festival, tapez 2. \n");
		int val = scan.nextInt();
		
		Festival f;
		Scene s ;
		Artiste a;
		
		if (val == 1) {
			System.out.println("Quel est le nom du festival que vous voulez cr�er ?");
			String nomfestival = scan.next();
			System.out.println("Quel est le nombre de places de votre festival ?");
			int nb = scan.nextInt();
			f = new Festival(nomfestival,nb);
			f.ajouterfestivalbdd();
			
			System.out.println(
			"Si vous voulez ajouter un nouvelle sc�ne � votre festival, tapez 3.\n"+
			"Si vous voulez ajouter du mat�riel au stock, tapez 4.\n"+
			"Si vous souhaitez ajouter un artiste et lui attribuer un horaire de concert, tapez 5.\n"+
			"Si vous souhaitez retirer un artiste et son concert, tapez 6.\n"+
			"Si vous souhaitez vider une sc�ne, tapez 7.\n");
			
			int valeur = scan.nextInt();
			if (valeur == 3) {
				String rep = "oui";
				while (rep.equals("oui")) {
					System.out.println("Bonjour, quel est le nom de la sc�ne que vous voulez cr�er ?");
					String nomscene = scan.next();
					System.out.println("Quelle est la surface de cette sc�ne ?");
					float surface = scan.nextFloat();
					System.out.println("Quel est le style de musique d�di� � cette sc�ne ?");
					String stylescene = scan.next();
					System.out.println("Quelle est la capacit� de cette sc�ne ?");
					int capacity = scan.nextInt();
					s = new Scene(nomscene, surface, stylescene, capacity);
					//f.addScene(s);
					s.ajouter_scene_bdd(nomscene, surface, stylescene, capacity);
					System.out.println("Voulez-vous ajouter une autre sc�ne ? (oui/non)");
					rep = scan.next();
					scan.nextLine();
				}
				}
			
			if (valeur == 4) {
				Materiel.ajouter_materiel_bdd();
			}
			

			if (valeur == 5) {
				System.out.println("Quel est le nom de l'artiste/du groupe que vous souhaitez inviter ? (pas d'espace svp)");
				String nomartiste = scan.next();
				System.out.println("Combien de personnes y a-t-il dans ce groupe ?");
				int nbpersonnes = scan.nextInt();
				System.out.println("Quel jour souhaitez-vous ajouter cet artiste ? (DD/MM/YYYY)");
				String jour = scan.next();
				System.out.println("Pour quelle somme ?");
				Float somme = scan.nextFloat();
				System.out.println("Quel est le style de l'artiste ? �crire en minuscule parmi: rap, rock, reggae, techno, electro");
				String styleartiste = scan.next();
				
				if (f.inviter_artiste(nomartiste, jour, somme) == true) {
					//creation of an artist
					a = new Artiste(nomartiste,nbpersonnes, somme, styleartiste);
					
					//ajouter l'artiste dans la base de donn�es
					a.ajouterartiste_bdd();
					System.out.println("L'artiste a �t� ajout� avec succ�s aux artistes du festival.\n");
					
					//On trouve alors la sc�ne relative au style de l'artiste
					PreparedStatement pStatement1 = connection.prepareStatement( "SELECT scene.id FROM scene WHERE style LIKE ?" );
					pStatement1.setString(1, a.getStyle());
					ResultSet result1 = pStatement1.executeQuery();
					result1.next();
					int idscenefin = result1.getInt("id");
					
					
					//On regarde l'heure de disponibilit� de cette sc�ne le jour o� on veut ajouter l'artiste
					//Scene.est_disponible(idscenefin, jour);
					
					//On regarde si le mat�riel demand� par l'artiste est dispo � cette heure
					
					ArrayList<String> listetype = new ArrayList<String>();
					ArrayList<Integer> listeqte = new ArrayList<Integer>();
					String rep = "oui"; //initialisation
					while (rep.equals("oui")) {
						System.out.println("De quel type de materiel avez-vous besoin?");
						String type = scan.next();
						System.out.println("En quelle quantit� (r�pondez par un entier)?");
						int qte = scan.nextInt();
						listetype.add(type);
						listeqte.add(qte);
						System.out.println(" Avez vous besoin de plus de mat�riel? oui/non ");
						rep = scan.next();
						scan.nextLine();
					}
					int n = listetype.size();
					
					for (int i=0;i<n;i++) {
						if (Materiel.verifier_disponibilite(listetype.get(i), listeqte.get(i), Scene.est_disponible(idscenefin, jour))==false) {
							PreparedStatement pStatement5 = connection.prepareStatement("SELECT COUNT (DISTINCT materiel.id) FROM materiel"+
									" JOIN concert ON concert.sceneid = materiel.id_scene"+
									" WHERE (type LIKE ? AND id_scene = 0)"+ 
									" OR (type LIKE ? AND (? >= heurefin))" + 
									" GROUP BY id_scene");
							pStatement5.setString(1, listetype.get(i));
							pStatement5.setString(2, listetype.get(i));
							pStatement5.setTime(3,  Scene.est_disponible(idscenefin, jour));
							ResultSet result5 = pStatement5.executeQuery();
							int nbd =0;
							if(result5.next()) {
								 nbd = result5.getInt("count");		
							}
							System.out.println("Il faut acheter "+ (listeqte.get(i) - nbd) + " de " + listetype.get(i));
						}
					}
					System.out.println("La phase de pr�paration se fera sur la sc�ne " + idscenefin + " le " + jour + " � " + Scene.est_disponible(idscenefin,jour));
					Time time = Time.valueOf("00:00:00");
					for (int i=0;i<n;i++) {
						Map<Integer, List<Integer>> m_Map =  Materiel.mapid(listetype.get(i), listeqte.get(i), Scene.est_disponible(idscenefin,jour));
						for (Integer idScene : m_Map.keySet()) {
							List<Integer> materials = m_Map.get(idScene);
							for (int j=0; j<materials.size();j++) {
								if (idScene != idscenefin) {
									Materiel.deplacer_materiel(materials.get(j), idScene, idscenefin);
										if (n == 1) {time.setTime(time.getTime() + Time.valueOf("01:05:00").getTime());} 
									    if (n == 2) {time.setTime(time.getTime() + Time.valueOf("01:10:00").getTime());} 
										if (n == 3) {time.setTime(time.getTime() + Time.valueOf("01:15:00").getTime());}
										if (n == 4) {time.setTime(time.getTime() + Time.valueOf("01:20:00").getTime());}
										if (n == 5) {time.setTime(time.getTime() + Time.valueOf("01:25:00").getTime());}
										if (n > 5) {time.setTime(time.getTime() + Time.valueOf("01:30:00").getTime());}
								}
							}
						}
					}
					Time h = Time.valueOf("00:00:00");
					h.setTime(Scene.est_disponible(idscenefin,jour).getTime() + time.getTime());
					Festival.ajouter_phase_preparation_bdd(jour, Scene.est_disponible(idscenefin,jour), h, idscenefin);
					System.out.println("Tous les concerts durent une heure.");
					Time heuredebutconcert = h;
					Time heurefinconcert = Time.valueOf("00:00:00");
					heurefinconcert.setTime(heuredebutconcert.getTime() + Time.valueOf("01:00:00").getTime());
					//cr�ation d'un concert
					System.out.println("Comment souhaitez-vous appeller ce concert ?");
					String nomconcert = scan.next();
					Concert c = new Concert(nomconcert,jour,heuredebutconcert,h,idscenefin);
					//ajouter le concert dans la liste
					//f.addConcert(c);
					//ajouter le concert dans la base de donn�es
					PreparedStatement pStatement10 = connection.prepareStatement("SELECT MAX (artiste.id) FROM artiste");
					ResultSet result10 = pStatement10.executeQuery();
					result10.next();
					int ida = result10.getInt(1);
					c.ajouter_concert_bdd(ida);
					System.out.println("Le concert a �t� ajout�.");
				}
			}
			
			if (valeur == 6) {
				System.out.println("Quel est le nom de l'artiste/du groupe que vous souhaitez annuler ?");
				String nomartiste = scan.next();
				PreparedStatement pStatement2 = connection.prepareStatement("SELECT * FROM artiste WHERE nomgroupe LIKE ?");
				pStatement2.setString(1, nomartiste);
				ResultSet result2 = pStatement2.executeQuery();
				result2.next();
				String nomart = result2.getString(2);
				int nbpersonnes = result2.getInt(3);	
				String style = result2.getString(4);
				float somme = result2.getInt(5);
				
				a = new Artiste(nomart,nbpersonnes, somme, style);
				f.annuler_participation(a);
			}
			
			if (valeur == 7) {
				System.out.println("Quel est l'identifiant de la sc�ne que vous souhaitez vider ?");
				Materiel.vider_scene(7);
			}
			
		}
		
		if (val == 2) {
			System.out.println("Quel est le nom du festival ?");
			String nomfestival = scan.next();
			PreparedStatement pStatement = connection.prepareStatement("SELECT * FROM festival WHERE nom LIKE ?");
			pStatement.setString(1, nomfestival);
			ResultSet result = pStatement.executeQuery();
			result.next();
			String nom = result.getString(1);
			int nb_places = result.getInt(2);	
			f = new Festival(nom,nb_places);
			
			System.out.println(
					"Si vous voulez ajouter un nouvelle sc�ne � votre festival, tapez 3.\n"+
					"Si vous voulez ajouter du mat�riel au stock, tapez 4.\n"+
					"Si vous souhaitez ajouter un artiste et lui attribuer un horaire de concert, tapez 5.\n"+
					"Si vous souhaitez retirer un artiste et son concert, tapez 6.\n");
					
					int valeur = scan.nextInt();
					if (valeur == 3) {
						String rep = "oui";
						while (rep.equals("oui")) {
							System.out.println("Bonjour, quel est le nom de la sc�ne que vous voulez cr�er ?");
							String nomscene = scan.next();
							System.out.println("Quelle est la surface de cette sc�ne ?");
							float surface = scan.nextFloat();
							System.out.println("Quel est le style de musique d�di� � cette sc�ne ?");
							String stylescene = scan.next();
							System.out.println("Quelle est la capacit� de cette sc�ne ?");
							int capacity = scan.nextInt();
							s = new Scene(nomscene, surface, stylescene, capacity);
							//f.addScene(s);
							s.ajouter_scene_bdd(nomscene, surface, stylescene, capacity);
							System.out.println("Voulez-vous ajouter une autre sc�ne ? (oui/non)");
							rep = scan.next();
							scan.nextLine();
						}
						}
					
					if (valeur == 4) {
						Materiel.ajouter_materiel_bdd();
					}
					
					if (valeur == 5) {
						System.out.println("Quel est le nom de l'artiste/du groupe que vous souhaitez inviter ? (pas d'espace svp)");
						String nomartiste = scan.next();
						System.out.println("Combien de personnes y a-t-il dans ce groupe ?");
						int nbpersonnes = scan.nextInt();
						System.out.println("Quel jour souhaitez-vous ajouter cet artiste ? (DD/MM/YYYY)");
						String jour = scan.next();
						System.out.println("Pour quelle somme ?");
						Float somme = scan.nextFloat();
						System.out.println("Quel est le style de l'artiste ? �crire en minuscule parmi: rap, rock, reggae, techno, electro");
						String styleartiste = scan.next();
						
						if (f.inviter_artiste(nomartiste, jour, somme) == true) {
							//creation of an artist
							a = new Artiste(nomartiste,nbpersonnes, somme, styleartiste);
							
							//ajouter l'artiste dans la base de donn�es
							a.ajouterartiste_bdd();
							System.out.println("L'artiste a �t� ajout� avec succ�s aux artistes du festival.\n");
							
							//On trouve alors la sc�ne relative au style de l'artiste
							PreparedStatement pStatement1 = connection.prepareStatement( "SELECT scene.id FROM scene WHERE style LIKE ?" );
							pStatement1.setString(1, a.getStyle());
							ResultSet result1 = pStatement1.executeQuery();
							result1.next();
							int idscenefin = result1.getInt("id");
							
							
							//On regarde l'heure de disponibilit� de cette sc�ne le jour o� on veut ajouter l'artiste
							//Scene.est_disponible(idscenefin, jour);
							
							//On regarde si le mat�riel demand� par l'artiste est dispo � cette heure
							
							ArrayList<String> listetype = new ArrayList<String>();
							ArrayList<Integer> listeqte = new ArrayList<Integer>();
							String rep = "oui"; //initialisation
							while (rep.equals("oui")) {
								System.out.println("De quel type de materiel avez-vous besoin?");
								String type = scan.next();
								System.out.println("En quelle quantit� (r�pondez par un entier)?");
								int qte = scan.nextInt();
								listetype.add(type);
								listeqte.add(qte);
								System.out.println(" Avez vous besoin de plus de mat�riel? oui/non ");
								rep = scan.next();
								scan.nextLine();
							}
							int n = listetype.size();
							
							for (int i=0;i<n;i++) {
								if (Materiel.verifier_disponibilite(listetype.get(i), listeqte.get(i), Scene.est_disponible(idscenefin, jour))==false) {
									PreparedStatement pStatement5 = connection.prepareStatement("SELECT COUNT (DISTINCT materiel.id) FROM materiel"+
											" JOIN concert ON concert.sceneid = materiel.id_scene"+
											" WHERE (type LIKE ? AND id_scene = 0)"+ 
											" OR (type LIKE ? AND (? >= heurefin))" + 
											" GROUP BY id_scene");
									pStatement5.setString(1, listetype.get(i));
									pStatement5.setString(2, listetype.get(i));
									pStatement5.setTime(3,  Scene.est_disponible(idscenefin, jour));
									ResultSet result5 = pStatement5.executeQuery();
									int nbd =0;
									if(result5.next()) {
										 nbd = result5.getInt("count");		
									}
									System.out.println("Il faut acheter "+ (listeqte.get(i) - nbd) + " de " + listetype.get(i));
								}
							}
							System.out.println("La phase de pr�paration se fera sur la sc�ne " + idscenefin + " le " + jour + " � " + Scene.est_disponible(idscenefin,jour));
							Time time = Time.valueOf("00:00:00");
							for (int i=0;i<n;i++) {
								Map<Integer, List<Integer>> m_Map =  Materiel.mapid(listetype.get(i), listeqte.get(i), Scene.est_disponible(idscenefin,jour));
								for (Integer idScene : m_Map.keySet()) {
									List<Integer> materials = m_Map.get(idScene);
									for (int j=0; j<materials.size();j++) {
										if (idScene != idscenefin) {
											Materiel.deplacer_materiel(materials.get(j), idScene, idscenefin);
												if (n == 1) {time.setTime(time.getTime() + Time.valueOf("01:05:00").getTime());} 
											    if (n == 2) {time.setTime(time.getTime() + Time.valueOf("01:10:00").getTime());} 
												if (n == 3) {time.setTime(time.getTime() + Time.valueOf("01:15:00").getTime());}
												if (n == 4) {time.setTime(time.getTime() + Time.valueOf("01:20:00").getTime());}
												if (n == 5) {time.setTime(time.getTime() + Time.valueOf("01:25:00").getTime());}
												if (n > 5) {time.setTime(time.getTime() + Time.valueOf("01:30:00").getTime());}
										}
									}
								}
							}
							Time h = Time.valueOf("00:00:00");
							h.setTime(Scene.est_disponible(idscenefin,jour).getTime() + time.getTime());
							Festival.ajouter_phase_preparation_bdd(jour, Scene.est_disponible(idscenefin,jour), h, idscenefin);
							System.out.println("Tous les concerts durent une heure.");
							Time heuredebutconcert = h;
							Time heurefinconcert = Time.valueOf("00:00:00");
							heurefinconcert.setTime(heuredebutconcert.getTime() + Time.valueOf("01:00:00").getTime());
							//cr�ation d'un concert
							System.out.println("Comment souhaitez-vous appeller ce concert ?");
							String nomconcert = scan.next();
							Concert c = new Concert(nomconcert,jour,heuredebutconcert,h,idscenefin);
							//ajouter le concert dans la liste
							//f.addConcert(c);
							//ajouter le concert dans la base de donn�es
							PreparedStatement pStatement10 = connection.prepareStatement("SELECT MAX (artiste.id) FROM artiste");
							ResultSet result10 = pStatement10.executeQuery();
							result10.next();
							int ida = result10.getInt(1);
							c.ajouter_concert_bdd(ida);
							System.out.println("Le concert a �t� ajout�.");
						}
					}
					
					if (valeur == 6) {
						System.out.println("Quel est le nom de l'artiste/du groupe que vous souhaitez annuler ?");
						String nomartiste = scan.next();
						PreparedStatement pStatement2 = connection.prepareStatement("SELECT * FROM artiste WHERE nomgroupe LIKE ?");
						pStatement2.setString(1, nomartiste);
						ResultSet result2 = pStatement.executeQuery();
						result2.next();
						String nomart = result2.getString(2);
						int nbpersonnes = result2.getInt(3);	
						String style = result2.getString(4);
						float somme = result2.getInt(5);
						
						a = new Artiste(nomart,nbpersonnes, somme, style);
						f.annuler_participation(a);
					}
					
					if (valeur == 7) {
						System.out.println("Quel est l'identifiant de la sc�ne que vous souhaitez vider ?");
						Materiel.vider_scene(7);
					}
					
		}
			
		
}
	}
