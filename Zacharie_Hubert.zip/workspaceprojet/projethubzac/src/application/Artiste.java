package application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Artiste {

	//Attributes
	private int id;
	private String nomgroupe;
	private int nbpersonnes;
	private float prix;
	private String style;
	
	//Constructor
	
	public Artiste(String nomdugroupe, int nombredepersonnes, float prix, String style) {
		this.nomgroupe = nomdugroupe;
		this.nbpersonnes = nombredepersonnes;
		this.prix = prix;
		this.style = style;
	}
	
	//Assessors
	public int getId() {
		//return the id of the artist/the group
		return this.id;
	}
	
	public String getNom() {
		//return the name of the artist/the group
		return this.nomgroupe;
	}
	
	public int getNbPersonnes() {
		//return the number of artists in the group
		return this.nbpersonnes;
	}
	
	public float getPrix() {
		//return the price
		return this.prix;
	}
	
	public String getStyle() {
		//return the style
		return this.style;
	}
	
	//Methods
	
	/**
	 * ajoute un nouvel artiste dans la base de donn�es
	 */
	
	public void ajouterartiste_bdd() throws SQLException {
		Connection connection = Connexion.getInstance();
		String sql = "INSERT INTO artiste (nomgroupe,nbpersonnes,style,prix) VALUES (?,?,?,?)";
		PreparedStatement pStatement = connection.prepareStatement(sql);
		pStatement.setString(1, this.getNom());
		pStatement.setInt(2, this.getNbPersonnes());
		pStatement.setString(3, this.getStyle());
		pStatement.setFloat(4, this.getPrix());
		pStatement.execute();
	}
	
}

